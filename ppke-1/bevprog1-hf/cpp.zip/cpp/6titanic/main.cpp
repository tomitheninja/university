#include <iostream>

using namespace std;

struct NAME
{
    // mezok
};

int main()
{
    return 0;
}