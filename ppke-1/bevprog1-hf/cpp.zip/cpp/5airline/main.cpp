struct AirLine
{
    // T name;
    // T million_km;
    // T fatalities_85_99;
    // T fatalities_00_14;
};

// operator >>
// operator <
// operator >
// beolvas()
// print(airline)

// legtöbb halott (abszolút)
// leghalálosabb (relatív)
// átlag halott / millió km
// keresett adatai (pl.: Lufthansa)