#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <iterator>
#include <functional>
#include <numeric>

using namespace std;

int integers()
{
    int x;
    x = 2;
    int negative_y = -10;

    // Összeadás
    x = x + 10;
    // növelés
    x += 10;

    // ------------
    int a = 10;
    int b = 3;
    // Szorzás
    int mul = a * b;

    // Osztás
    int div = a / b; // Tipp?

    int c = 2.2;

    cerr << "div = " << c << endl;

    cerr << "Kérdés?" << endl;
}

float real_numbers()
{
    float a = 120.0;
    float b = 2.781828182845904523;

    float sum = 0.1 + 0.2;
    cerr << sum << endl;
    if (sum == 0.3)
    {
        cerr << "0.3" << endl;
    }
    else
    {
        cerr << "WTF" << endl;
    }

    float diff = abs(sum - 0.3);

    if (diff < 0.001)
    {
        cerr << "0.3" << endl;
    }

    float mul = 15 * 0.5;
    float div = 10 / 3;

    cerr << div << endl;

    int int_three = 3;

    float div_good = 10.0 / (double)int_three;

    cerr << div_good << endl;

    cerr << "Kérdés?" << endl;
}

char characters()
{
    char c = 'F';

    if ('a' <= c && c <= 'z')
    {
        cerr << "c is an lowercase character" << endl;
    }

    else if ('A' <= c && c <= 'Z')
    {
        cerr << "c is an uppercase character" << endl;
    }

    else if ('0' <= c && c <= '9')
    {
        cerr << "c is a digit stored as character" << endl;
    }

    cout << (3 == '3') << endl;

    // Speciális karakterek

    cerr << "-> <-" << endl;
    cerr << "->\t<-" << endl;
    cerr << "->\n<-" << endl;

    cerr << "Kérdés?" << endl;
}

void booleans()
{
    bool is_good = true;
    bool is_bad = !is_good;

    cerr << "booleans: " << is_good << ' ' << is_bad << endl;

    cerr << "Kérdés?" << endl;
}

void vectors()
{
    vector<int> v;
    cerr << v.size() << endl;
    v.push_back(10);
    v.push_back(20);
    v.push_back(30);
    cerr << v.size() << endl;

    // Antipattern
    v.resize(10);

    cerr << v[0] << endl;
    cerr << v[v.size() - 1] << endl;

    cerr << "Kérdés" << endl;
}

void strings()
{
    string s1 = "fooBar";
    s1 = "fooBarBaz";

    cerr << s1 << endl;
    int pos = s1.find("bar");

    // https://devdocs.io/cpp/string/basic_string/find
    if (pos != string::npos)
    {
        cerr << "1) found at i=" << pos << endl;
    }
    else
    {
        cerr << "1) not found" << endl;
    }

    s1 += 'c';
    string upper_s1;
    for (int i = 0; i < s1.length(); i++)
    {
        upper_s1 += toupper(s1[i]);
    }

    int pos2 = upper_s1.find("BAR");

    if (pos2 != string::npos)
    {
        cerr << "2) found at i=" << pos2 << endl;
    }
    else
    {
        cerr << "2) not found" << endl;
    }

    cerr << "Kérdés?" << endl;
}

void _size_t() {
	cout << "You don't need me" << endl;
}

int main()
{
    integers();
    real_numbers();
    characters();
    booleans();
    vectors();
    strings();
	_size_t();	
	
    return 0;
}