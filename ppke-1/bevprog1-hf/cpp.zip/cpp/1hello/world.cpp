#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    int a = 123;
    ifstream f("be.txt");
    if (!f.is_open())
    {
        cerr << "Error opening file" << endl;
        return 1;
    }
    string msg;
    getline(f, msg);
    cout << "message = " << msg << endl;
    f.close();
    return 0;
}