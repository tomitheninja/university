#include <iostream>
#include <vector>

using namespace std;

/*
visszatérési_típus függvény_név(típus paraméter1, típus paraméter2)
{
    // .. code here
    int result = 0;
    result += 42;
    return result;
}
*/

// Pont azt csinálja, amire számítasz a neve alapján
// Nem ír ki a konzolra
// Nem módosítja a paramétereit
// Mindig ugyan azt az eredményt produkálja adott a és b-re
int sum(int a, int b)
{
    return a + b;
}

// a neve utal rá, hogy miért nem ad vissza semmit
// nem módosítja a paramétereit
// az ilyen eljárások gyakran void vagy bool (hibakód) visszatérési típusúak
// mert a "kimenetük" nem a programunk, hanem a konzol
void print_vector(vector<int> v)
{
    for (int i = 0; i < v.size(); i++)
    {
        cerr << v[i] << ' ';
    }
    cerr << endl;
}

// ----------------------------------------------------------------
// Adat kijuttatása a függvényből
void by_param(int &a) // az eredmeny valtozot paraméterként kapom
{
    a = 10; // és csak értéket állítok be neki
}

int main1()
{
    int kulso_a;
    by_param(kulso_a);
    cout << kulso_a << endl;
}

int by_return()
{
    // felveszek egy eredmeny valtozot a függvényen belül
    int result = 10;
    return result; // és ezt adom vissza
}

int main2()
{
    cerr << by_return() << endl;
    // vagy lementhetem egy változóban is
    int kulso_eredmeny = by_return();
    cout << kulso_eredmeny << endl;
}

int main()
{
    cout << "sum(1,2) = " << sum(1, 2) << endl;
    vector<int> v{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    print_vector(v);
    main1();
    main2();
}