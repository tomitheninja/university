#include <iostream>
#include <vector>

using namespace std;

// Létrehoz egy n*n-es szorzótáblát
T szorzotabla(int n)
{
}

int main()
{
    int n;
    cin >> n;
    // T tabla = szorzotabla(n);
}